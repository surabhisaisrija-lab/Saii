from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# FAQs
faq_questions = [
    "What is AI?",
    "What is Python?",
    "What is Machine Learning?",
    "What is CodeAlpha?"
]

faq_answers = [
    "AI stands for Artificial Intelligence.",
    "Python is a popular programming language.",
    "Machine Learning is a subset of AI.",
    "CodeAlpha provides internship opportunities and projects."
]

vectorizer = TfidfVectorizer()
faq_vectors = vectorizer.fit_transform(faq_questions)

print("FAQ Chatbot Started!")
print("Type 'exit' to stop.\n")

while True:
    user_input = input("You: ")

    if user_input.lower() == "exit":
        print("Chatbot: Goodbye!")
        break

    user_vector = vectorizer.transform([user_input])

    similarity = cosine_similarity(user_vector, faq_vectors)

    best_match = similarity.argmax()

    print("Chatbot:", faq_answers[best_match])