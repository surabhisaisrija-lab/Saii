import streamlit as st
from deep_translator import GoogleTranslator

st.title("🌍 Language Translation Tool")

text = st.text_area("Enter Text")

if st.button("Translate"):

    translated = GoogleTranslator(
        source='en',
        target='te'
    ).translate(text)

    st.success("Translated Text:")

    st.write(translated)